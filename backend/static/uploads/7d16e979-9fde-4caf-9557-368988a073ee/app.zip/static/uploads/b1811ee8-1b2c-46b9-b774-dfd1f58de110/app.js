document.addEventListener('DOMContentLoaded', function() {
    const homeButton = document.getElementById('homeButton');
    const contactForm = document.getElementById('contactForm');

    homeButton.addEventListener('click', function() {
        alert('Home button clicked!');
    });

    contactForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const message = document.getElementById('message').value;
        alert(`Form submitted! Name: ${name}, Email: ${email}, Message: ${message}`);
    });

    // Additional JavaScript functionality
    const services = document.querySelectorAll('.service');
    services.forEach(service => {
        service.addEventListener('click', function() {
            alert(`Service clicked: ${service.querySelector('h3').innerText}`);
        });
    });

    const portfolioItems = document.querySelectorAll('.portfolio-item');
    portfolioItems.forEach(item => {
        item.addEventListener('click', function() {
            alert(`Portfolio item clicked: ${item.querySelector('h3').innerText}`);
        });
    });

    // Simulate loading data
    setTimeout(() => {
        console.log('Data loaded');
    }, 2000);

    // Example of using fetch API
    fetch('https://jsonplaceholder.typicode.com/posts')
        .then(response => response.json())
        .then(data => {
            console.log('Fetched data:', data);
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });

    // Example of using async/await
    async function fetchData() {
        try {
            const response = await fetch('https://jsonplaceholder.typicode.com/posts');
            const data = await response.json();
            console.log('Fetched data with async/await:', data);
        } catch (error) {
            console.error('Error fetching data with async/await:', error);
        }
    }

    fetchData();
});