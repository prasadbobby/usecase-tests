# Identified Test Flows

## ButtonPage_click_button_homeButton

**Type:** interaction

**Description:** Click button_homeButton on ButtonPage

**Steps:**

1. Navigate ButtonPage
2. Click button_homeButton

---

